package Tp8Exo2;

public class Test {
}

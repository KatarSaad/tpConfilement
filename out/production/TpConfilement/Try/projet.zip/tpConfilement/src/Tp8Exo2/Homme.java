package Tp8Exo2;

public interface Homme {
    public void identité();

}

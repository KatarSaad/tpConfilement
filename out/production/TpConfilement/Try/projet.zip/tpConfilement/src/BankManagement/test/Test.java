package BankManagement.test;

public class Test {
    public static void main(String[] args) {
        Client client=new Client("alex","255d4",18882,1223);
        client.showMenu();

    }
}

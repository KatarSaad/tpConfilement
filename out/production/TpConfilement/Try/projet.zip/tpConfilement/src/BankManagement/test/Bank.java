package BankManagement.test;

public class Bank {
}

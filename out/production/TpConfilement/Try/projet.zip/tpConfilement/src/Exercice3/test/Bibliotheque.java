package Exercice3.test;

public abstract  class Bibliotheque {//no instanstiation for abstract classes
    protected abstract boolean addBook(Livre livre);
     public abstract boolean removeBook(Livre livre );


}

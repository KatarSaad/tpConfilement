package Exercice3.test;//heritage multiple a un probleme: les attributs peuvent etre dupliqué...
import java.util.*;
public class Exo3 {
    public static void main(String[] args) {
     LinkedList<Livre> l=new LinkedList<Livre>();//

    }
}

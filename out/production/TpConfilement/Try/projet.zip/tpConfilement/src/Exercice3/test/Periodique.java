package Exercice3.test;

public class Periodique {
    public String nom;
    public String prenom ;
    public int periodicité;

}

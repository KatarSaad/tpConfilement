package Tp8Exo3.test;

public class Chien extends Mamifere{
    public Chien(String nom,String parole,int vitesse )
    {
        super(nom,parole,vitesse);

    }

}

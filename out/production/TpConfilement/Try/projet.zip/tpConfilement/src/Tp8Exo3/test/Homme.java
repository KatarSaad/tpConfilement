package Tp8Exo3.test;

public class Homme extends Mamifere{

    //private String parole;
   //private int vitesse;

    public Homme(String nom, String parole, int vitesse)
    {
        super(nom,parole, vitesse);


    }

}

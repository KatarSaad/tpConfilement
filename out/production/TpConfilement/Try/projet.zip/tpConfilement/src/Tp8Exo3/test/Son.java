package Tp8Exo3.test;

public interface Son {
    public void parler();
}

package Tp8;

public class Exo1 {
    public static void main(String[] args) {

    }
}

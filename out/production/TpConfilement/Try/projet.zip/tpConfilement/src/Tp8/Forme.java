package Tp8;

public interface  Forme {
    public double cote=0;
    public double perimetre ();
    public double aire ();

}
